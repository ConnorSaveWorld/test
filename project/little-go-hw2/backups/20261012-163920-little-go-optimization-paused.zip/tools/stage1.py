"""Stage 1 local rehearsal: run the actual submission in a fresh process.

Requires Unix child CPU accounting. Opponent proxies are not official graders.
"""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time
try:
    import resource
except ImportError:
    resource=None
from benchmark import ROOT, tournament, InvalidMove
from probe_deployment import validate_action


def child_cpu():
    if resource is None:
        raise RuntimeError('Unix resource accounting is required')
    usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime+usage.ru_stime


def submission_policy(folder,cpu_override=None,source_path=None):
    folder=pathlib.Path(folder)
    source_path=ROOT/'submission'/'my_player3.py' if source_path is None else pathlib.Path(source_path)
    env=dict(os.environ)
    env.pop('LITTLE_GO_CPU_SECONDS',None)
    if cpu_override is not None:
        env['LITTLE_GO_CPU_SECONDS']=str(cpu_override)
    def policy(state,rng):
        text=str(state['color'])+'\n'
        for board in (state['previous'],state['board']):
            text+='\n'.join(''.join(map(str,board[r:r+5])) for r in range(0,25,5))+'\n'
        input_path=folder/'input.txt'
        input_path.write_text(text,encoding='ascii')
        output_path=folder/'output.txt'
        if output_path.exists():
            output_path.unlink()
        before=child_cpu()
        try:
            completed=subprocess.run([sys.executable,str(source_path)],
                cwd=str(folder),env=env,timeout=10,capture_output=True)
        except subprocess.TimeoutExpired as error:
            error.child_cpu=child_cpu()-before
            raise
        used=child_cpu()-before
        if completed.returncode:
            error=RuntimeError(completed.stderr.decode(errors='replace'))
            error.child_cpu=used
            raise error
        if not output_path.exists():
            error=InvalidMove('No output.txt from submission')
            error.child_cpu=used
            raise error
        text=output_path.read_text(encoding='ascii').strip()
        try:
            point=validate_action(text,str(input_path))
        except ValueError as original:
            error=InvalidMove(str(original))
            error.child_cpu=used
            raise error
        stats={'child_cpu':used}
        history_path=folder/'state.json'
        if history_path.exists():
            record=json.loads(history_path.read_text())
            stats.update(record.get('last_stats',{}))
            stats['child_cpu']=used
        return point,stats
    return policy


def run(opponent,games=20,seed=561100,source=None,tag=''):
    source_path=ROOT/'submission'/'my_player3.py' if source is None else ROOT/source
    prefix='stage1-'+(tag+'-' if tag else '')
    path=ROOT/'reports'/(prefix+opponent+'.json')
    progress=ROOT/'reports'/(prefix+opponent+'-progress.json')
    began=time.monotonic()
    def checkpoint(results):
        wins=sum(g['winner']==g['agent_color'] for g in results)
        data={'opponent':opponent,'completed':len(results),'planned':games,
              'wins':wins,'wall_seconds':time.monotonic()-began,
              'by_color':{str(c):{'games':sum(g['agent_color']==c for g in results),
                                'wins':sum(g['agent_color']==c and g['winner']==c for g in results)} for c in (1,2)}}
        temp=progress.with_suffix('.tmp')
        temp.write_text(json.dumps(data,indent=2))
        os.replace(str(temp),str(progress))
        print('{} {}/{} wins={}'.format(opponent,len(results),games,wins),flush=True)
    with tempfile.TemporaryDirectory(prefix='littlego-stage1-') as folder:
        report=tournament(opponent,games,seed,3.0,agent_name='submission-process',
                          policy_override=submission_policy(folder,source_path=source_path),on_game=checkpoint)
    report['configuration'].update({'execution':'actual my_player3.py subprocess per move',
        'cpu_accounting':'parent policy CPU + Unix RUSAGE_CHILDREN user/system CPU',
        'cpu_seconds':3.0,'wall_seconds':4.0,'persistent_helper':'validated state.json'})
    report['total_agent_cpu']=sum(g['cpu_by_color'][g['agent_color']] for g in report['results'])
    report['source_sha256']=hashlib.sha256(source_path.read_bytes()).hexdigest()
    report['source_path']=str(source_path)
    report['elapsed_wall']=time.monotonic()-began
    report['limitations']='Local Stage1 rehearsal. Only Random is course-original; other opponents are proxies. Vocareum not tested.'
    path.write_text(json.dumps(report,indent=2))
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2))
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--opponent',required=True,choices=('official-random','greedy-proxy','aggressive-proxy','alphabeta-proxy'))
    parser.add_argument('--games',type=int,default=20)
    parser.add_argument('--seed',type=int,default=561100)
    parser.add_argument('--source')
    parser.add_argument('--tag',default='')
    args=parser.parse_args()
    if args.games<=0 or args.games%2:
        parser.error('games must be positive and even')
    run(args.opponent,args.games,args.seed,args.source,args.tag)

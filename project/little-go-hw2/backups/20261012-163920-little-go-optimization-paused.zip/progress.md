# Execution ledger — 2026-10-12-little-go

Spec and implementation plan are approved. User explicitly requested direct generation and no additional confirmation gates.

Ruling: Work in a new project-local directory, not a Git worktree — the project mirror is not a Git repository and sources/ is read-only. No unrelated repository will be modified or initialized.

Pre-flight: rules -> protocol/search/benchmark use immutable 25-cell boards and PASS=-1; score uses signed Black advantage with komi. Search -> benchmark reports actual configuration and timing. Optional learning never determines legality.

Ruling: Benchmarks use short explicitly reported CPU budgets for development, followed by deployment-budget probes — large 3-second-per-decision tournaments require substantial time and cannot be inferred from short-budget results.

Task 1: in progress. Tests first; official sources are copied byte-for-byte for reference only.

Task 1: complete — 10 initial rule tests went red before implementation, then green; 25,000 candidate transitions over 1,000 reachable positions match both original GO and an independent matrix oracle.
Task 2: complete — protocol/history/fresh-process tests passed. Review found huge-integer helper CPU overflow and White empty-opening PASS recognition; both reproduced and fixed with regression tests.
Task 3: complete — exhaustive short-horizon oracle comparison and genuine TT-hit depth-6 fixture passed. Cached and uncached value 10002.5 agree; cache hits were actually nonzero.
Task 4: complete locally — tournament harness tests passed; 200 games per Random/Greedy proxy/Aggressive proxy/Alpha-beta proxy at 0.025 CPU budget. Larger Alpha-beta experiments and original file-host matches are recorded separately.
Task 5: complete as baseline calibration — same-seed Alpha-beta 0.2 budget 32/40 versus 0.75 budget 38/40; separate 3-second sample 9/10. Diagnostic profile shows ordering/TT can complete slightly greater depths. No unmeasured bitboard or tactical-extension change deployed.
Ruling: Keep simple tuple representation and no selective tactical pruning — correctness verified and time allocation already improves the proxy result; additional representation complexity is not justified by current evidence.
Task 6: local experiment complete — original linear TD(0) trained 1,000 games, then held-out40 per variant; search18 wins, learned0, hybrid1. Reject model and keep search-only. Learned ordering deferred because the value model clearly regressed; no advanced hidden-player result inferred.
Task 7: complete for local delivery — actual CPython3.7.5 full36-test suite passed, default-budget fresh-process official-host matches completed, all48 logged actions independently replayed as legal and terminal scores matched. Additional corrected prevalidation probe passed. Clean zip contains only my_player3.py and exactly matches source bytes.
Ruling: No commits/worktree integration — this artifact directory is not a Git repository. Original downloads and sources/ remain unchanged.
Ruling: Runtime build source/logs generated in project root were moved into dedicated little-go-hw2/.runtime/ after all build processes ended. Relocated CPython3.7.5 ran all36 tests successfully; no global interpreter installation.
Review: Independent read-only reviewer identified two production edge cases and one probe detection issue, all corrected. Probe now validates each output using a fresh official GO before accepting host exit codes. Historical default-budget traces also independently validated.
Remaining external validation: Vocareum actual CPU wrapper and helper persistence, formal Alpha-beta/Q-learning/Championship reports, and course AI-use policy. These are explicitly unknown in delivery documents, not silently marked passing.

2026-10-12 additional user request: test Stage1 first. Completed actual CPython3.7.5 fresh-process rehearsal at unchanged default3s budget: officialRandom20/20, GreedyProxy20/20, AggressiveProxy20/20, AlphaProxy16/20 (Black10/10, White6/10). 80-game agent CPU2060.997s versus7200 limit; max decision CPU3.2712s; zero invalid/timeout/crash counts. Proxy rubric83/90, explicitly not an official score prediction. All80 final scores and24-step traces independently checked against stone+komi outcome.
Stage1 tools: Unix RUSAGE_CHILDREN accounting tested with real child invocation; reported timeout childCPU included. Review found failed-action timing missing in generic harness; reproduced, corrected and regression tested. Full39-test suite passed on actual3.7.5. Running rehearsal workers had zero failures, so the exception-reporting fix does not alter their outcomes or timing metrics.
Stage1 investigation: Four White losses share two repeated White action sequences; their full two-player trajectories are distinct; intermediate positive heuristics preceded fully searched losing endings. No strategy changes during test; no precise causal claim or unmeasured fix. Detailed loss records in reports/STAGE1-LOSSES.md. Next optimization target is White versus search opponents, with independent held-out seeds and full opponent regression checks.
